package com.core.sports;

public class Chess extends SportsGroup {
	
	
	
	public void display()
	{
		System.out.println("Its working!!! Chess");
		//nothing
	}
}
