package com.core.sports;

import java.util.HashMap;

public class Cricket extends SportsGroup

{
	
	private HashMap<String,String> batsman;
	private HashMap<String,String> bowler;
	private boolean isAllRounder;
	private boolean isSkipper;//Captain
	private boolean isWicketKeeper;
	private String specialSkill;
	
	public HashMap<String, String> getBatsman() {
		return batsman;
	}
	public void setBatsman(HashMap<String, String> batsman) {
		this.batsman = batsman;
	}
	public HashMap<String, String> getBowler() {
		return bowler;
	}
	public void setBowler(HashMap<String, String> bowler) {
		this.bowler = bowler;
	}
	public boolean isAllRounder() {
		return isAllRounder;
	}
	public void setAllRounder(boolean isAllRounder) {
		this.isAllRounder = isAllRounder;
	}
	public boolean isSkipper() {
		return isSkipper;
	}
	public void setSkipper(boolean isSkipper) {
		this.isSkipper = isSkipper;
	}
	public boolean isWicketKeeper() {
		return isWicketKeeper;
	}
	public void setWicketKeeper(boolean isWicketKeeper) {
		this.isWicketKeeper = isWicketKeeper;
	}
	public String getSpecialSkill() {
		return specialSkill;
	}
	public void setSpecialSkill(String specialSkill) {
		this.specialSkill = specialSkill;
	}
	
}
