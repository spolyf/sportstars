package com.core.spolyf;


import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.core.sports.SportsGroup;



@Document(collection="sportstars")
public class SportStar {
 
	@Id
    private String id;
    
    private long spolyf_id;
    private String fullName;
    private String nickName;
	private String profilePicURL;
	private String currentCity;
	private String height;
	private String weight;
	private String sex;
	private String education;
	private String occupation;
	private String age;
	private SportsGroup sportsGroup;
	private String profileBannerURL;
	private long fanscount;
	private String sportsName;
	private Address address;
	private long rating;
	private String certifiedStampURL;
	private String dob;
	private String aboutMe;
	private List<String> photos;
	private List<String> videos;
	private String profileVideoURL;
	private String level;
	private String status; //active not active
	
	public List<String> getPhotos() {
		return photos;
	}
	public void setPhotos(List<String> photos) {
		this.photos = photos;
	}
	public List<String> getVideos() {
		return videos;
	}
	public void setVideos(List<String> videos) {
		this.videos = videos;
	}
	public String getAboutMe() {
		return aboutMe;
	}
	public void setAboutMe(String aboutMe) {
		this.aboutMe = aboutMe;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public long getRating() {
		return rating;
	}
	public void setRating(long rating) {
		this.rating = rating;
	}
	
	public String getCertifiedStampURL() {
		return certifiedStampURL;
	}
	public void setCertifiedStampURL(String certifiedStampURL) {
		this.certifiedStampURL = certifiedStampURL;
	}
	
	public String getSportsName() {
		return sportsName;
	}
	public void setSportsName(String sportsName) {
		this.sportsName = sportsName;
	}
	public SportsGroup getsportsGroup() {
		return sportsGroup;
	}
	public void setsportsGroup(SportsGroup sportsGroup) {
		this.sportsGroup = sportsGroup;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public long getSpolyf_id() {
		return spolyf_id;
	}
	public void setSpolyf_id(long spolyf_id) {
		this.spolyf_id = spolyf_id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getProfilePicURL() {
		return profilePicURL;
	}
	public void setProfilePicURL(String profilePicURL) {
		this.profilePicURL = profilePicURL;
	}
	public String getCurrentCity() {
		return currentCity;
	}
	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
	public String getProfileBannerURL() {
		return profileBannerURL;
	}
	public void setProfileBannerURL(String profileBannerURL) {
		this.profileBannerURL = profileBannerURL;
	}
	public long getFanscount() {
		return fanscount;
	}
	public void setFanscount(long fanscount) {
		this.fanscount = fanscount;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getProfileVideoURL() {
		return profileVideoURL;
	}
	public void setProfileVideoURL(String profileVideoURL) {
		this.profileVideoURL = profileVideoURL;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
 
 // getters and setters omitted for brevity
}