package com.core.spolyf;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.core.spolyf.SportStar;
import com.core.spolyf.SportStarMinRepository;
import com.core.spolyf.SportStarRepository;




@CrossOrigin
@RestController
@RequestMapping("/profiledetails")
public class ProfileController {

     
    @Autowired
    SportStarRepository starRepository;
    
    @Autowired
    SportStarMinRepository starMinRepository;
    
    @Autowired
	protected MongoTemplate mongoTemplate;
	
	@Autowired
	protected MongoOperations mongoOperation;
	
   
                                                    
    @RequestMapping(method = RequestMethod.POST)
    public SportStar create(@RequestBody SportStar star){
    	SportStar result = starRepository.save(star);
        return result;
    }
    
    
    
     
    @RequestMapping(method = RequestMethod.GET, value="/{spolyf_id}")
    public Profile get(@PathVariable String spolyf_id){
    	Profile profiledetails = null;
		Query query = new Query();
		query.addCriteria(Criteria.where("spolyf_id").is(spolyf_id));
		profiledetails = mongoOperation.findOne(query, Profile.class);
		return profiledetails;
        
    }
    
    
}