package com.core.spolyf;

public class StarPhysique {
	
	private String spolyf_id;
	private String body_color;
	private String height;
	private String weight;
	private String chest;
	private String hair_color;
	
	public String getSpolyf_id() {
		return spolyf_id;
	}
	public void setSpolyf_id(String spolyf_id) {
		this.spolyf_id = spolyf_id;
	}
	public String getBody_color() {
		return body_color;
	}
	public void setBody_color(String body_color) {
		this.body_color = body_color;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getChest() {
		return chest;
	}
	public void setChest(String chest) {
		this.chest = chest;
	}
	public String getHair_color() {
		return hair_color;
	}
	public void setHair_color(String hair_color) {
		this.hair_color = hair_color;
	}
	
	
	

}
