package com.core.spolyf;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;




@CrossOrigin
@RestController
@RequestMapping("/sportstarss")
public class SSController {

     
    @Autowired
    SportStarRepository starRepository;
    
    @Autowired
    SportStarMinRepository starminRepository;
    
   
                                                    
    @RequestMapping(method = RequestMethod.POST)
    public SportStar create(@RequestBody SportStar star){
    	SportStar result = starRepository.save(star);
        return result;
    }
     
    @RequestMapping(method = RequestMethod.GET, value="/{mangoId}")
    public SportStar get(@PathVariable String mangoId){
        return starRepository.findOne(mangoId);
    }
    
     
    @RequestMapping(method = RequestMethod.GET)
    public List<SportStar> getall(){
        return starRepository.findAll();
    }
    
    @RequestMapping(method = RequestMethod.GET,value="/min/{mangoId}")
    public List<SportStarMin> getallmin(){
        return starminRepository.findAll();
    }
    	
    @RequestMapping(method = RequestMethod.POST,value="/addall")
    public List<SportStar> createMany(@RequestBody List<SportStar> entities){
         
        List<SportStar> result = starRepository.save(entities);
        return result;
    }
    
}