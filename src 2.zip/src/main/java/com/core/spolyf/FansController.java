package com.core.spolyf;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Controller
@CrossOrigin
@RestController
@RequestMapping("/fans")
public class FansController {
	
	     
	@Autowired
	FansRepository fansRepository;
	
	@Autowired
	protected MongoTemplate mongoTemplate;
	
	@Autowired
	protected MongoOperations mongoOperation;
	
	
	@RequestMapping(method = RequestMethod.GET, value="/{spolyf_id}")
	public Fans get(@PathVariable String spolyf_id){
	        return fansRepository.findOne(spolyf_id);
	    }
	 
	
	@RequestMapping(method = RequestMethod.GET)
    public List<Fans> getall(){
        return fansRepository.findAll();
    }
	
	@RequestMapping(method = RequestMethod.POST,value="/fanit")
    public Fans fanit(@RequestBody Fans fan){ 
		try
		{
		System.out.println("Logssss::::"+fan.getSpolyf_id());
		Query query = new Query(Criteria.where("spolyf_id").is(fan.getSpolyf_id()));
		Update updatefans = new Update().set(fan.getUser_id(),true);
		mongoTemplate.upsert(query, updatefans, "fans");
		}
		catch(Exception e)
		{
			
		}
		finally
		{
    	
		}
		return null;
    }
	
	@RequestMapping(method = RequestMethod.POST,value="/unfanit")
    public Fans unfanit(@RequestBody Fans fan){ 
		Query query = new Query(Criteria.where("spolyf_id").is(fan.getSpolyf_id()));
		Update updatefancount = new Update().set("fanscount",fan.getFanscount()-1);
		Update updatefans = new Update().set("fans",fan.getFans().put("j", true));
		mongoTemplate.upsert(query, updatefancount, "fans");
		mongoTemplate.upsert(query, updatefans, "fans");
    	return null;
    }

}
