package com.core.spolyf;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="academy")
public class Academy {
	
	@Id
	private String id;
	
	private String academy_id;
	
	private String academyName;// School Name, Andhra Cricket Association
	
	private String academyType; // Individual, School, University, Private Academy, Board
	
	private String city;// Hyderabad,Mumbai
	
	private Address address;
	
	private String academyPic;
	
	private String primaryBusiness;
	
	
	
	
	
	public String getPrimaryBusiness() {
		return primaryBusiness;
	}

	public void setPrimaryBusiness(String primaryBusiness) {
		this.primaryBusiness = primaryBusiness;
	}

	private List<String> sportstars;

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAcademy_id() {
		return academy_id;
	}

	public void setAcademy_id(String academy_id) {
		this.academy_id = academy_id;
	}

	public String getAcademyName() {
		return academyName;
	}

	public void setAcademyName(String academyName) {
		this.academyName = academyName;
	}

	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	/*public List<SportStar> getSportstars() {
		return sportstars;
	}

	public void setSportstars(List<SportStar> sportstars) {
		this.sportstars = sportstars;
	}
	*/

	public String getAcademyType() {
		return academyType;
	}

	public void setAcademyType(String academyType) {
		this.academyType = academyType;
	}

	public String getAcademyPic() {
		return academyPic;
	}

	public void setAcademyPic(String academyPic) {
		this.academyPic = academyPic;
	}

	public List<String> getSportstars() {
		return sportstars;
	}

	public void setSportstars(List<String> sportstars) {
		this.sportstars = sportstars;
	}
	
	
	
	

}
