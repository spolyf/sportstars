package com.core.spolyf;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author AHS
 * At present, Organizer will be an individual, not an entity/company
 *
 */
@Document(collection="organizer")
public class Organizer {
	
	@Id
	private String id;
	
	private String organizer_id;
	
	private String spolyf_id;
	
	private Tournament tournament_id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrganizer_id() {
		return organizer_id;
	}

	public void setOrganizer_id(String organizer_id) {
		this.organizer_id = organizer_id;
	}

	public String getSpolyf_id() {
		return spolyf_id;
	}

	public void setSpolyf_id(String spolyf_id) {
		this.spolyf_id = spolyf_id;
	}

	public Tournament getTournament_id() {
		return tournament_id;
	}

	public void setTournament_id(Tournament tournament_id) {
		this.tournament_id = tournament_id;
	}
	
	

}
