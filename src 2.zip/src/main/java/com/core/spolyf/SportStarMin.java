package com.core.spolyf;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



@Document(collection="sportstars")
public class SportStarMin {
 
	@Id
    private String id;
    
    private long spolyf_id;
    private String fullName;
    private String level;
    private String nickName;
    private String profilePicURL;
    private String profileBannerURL;
	private String currentCity;
	private long fanscount;
	private String sportsName;
	private String certifiedStampURL;
	private String status;
	
	
	
    
    
	public String getCertifiedStampURL() {
		return certifiedStampURL;
	}
	public void setCertifiedStampURL(String certifiedStampURL) {
		this.certifiedStampURL = certifiedStampURL;
	}
	public String getSportsName() {
		return sportsName;
	}
	public void setSportsName(String sportsName) {
		this.sportsName = sportsName;
	}
	public String getProfileBannerURL() {
		return profileBannerURL;
	}
	public void setProfileBannerURL(String profileBannerURL) {
		this.profileBannerURL = profileBannerURL;
	}
	public long getFanscount() {
		return fanscount;
	}
	public void setFanscount(long fanscount) {
		this.fanscount = fanscount;
	}
	public String getProfilePicURL() {
		return profilePicURL;
	}
	public void setProfilePicURL(String profilePicURL) {
		this.profilePicURL = profilePicURL;
	}
	public String getCurrentCity() {
		return currentCity;
	}
	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public long getSpolyf_id() {
		return spolyf_id;
	}
	public void setSpolyf_id(long spolyf_id) {
		this.spolyf_id = spolyf_id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	
}