package com.core.spolyf;

import org.springframework.data.mongodb.repository.MongoRepository;;

public interface AcademyRepository extends
MongoRepository<Academy, String> {
 
}