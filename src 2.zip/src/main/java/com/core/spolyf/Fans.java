package com.core.spolyf;

import java.util.HashMap;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


// One to Many : Spolyf ID : {Fan1, Fan2, Fan3}

@Document(collection="fans")
public class Fans {
	
	@Id
	private String id;
	
	private String spolyf_id;
	private String user_id;
	
	private long fanscount;
	private Map<String,Boolean> fans; // Key:UserID, Value: true/false

	
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSpolyf_id() {
		return spolyf_id;
	}

	public void setSpolyf_id(String spolyf_id) {
		this.spolyf_id = spolyf_id;
	}

	
	public long getFanscount() {
		return fanscount;
	}

	public void setFanscount(long fanscount) {
		this.fanscount = fanscount;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public Map<String, Boolean> getFans() {
		return fans;
	}

	public void setFans(Map<String, Boolean> fans) {
		this.fans = fans;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//To Do

}
