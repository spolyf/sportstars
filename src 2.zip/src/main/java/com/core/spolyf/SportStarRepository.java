package com.core.spolyf;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface SportStarRepository extends
MongoRepository<SportStar, String> {
 
}