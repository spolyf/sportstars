package com.core.spolyf;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.core.spolyf.Fans;

public interface FansRepository extends
MongoRepository<Fans, String> {
 
}