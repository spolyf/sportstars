package com.core.spolyf;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.core.spolyf.SportStar;
import com.core.spolyf.SportStarMin;
import com.core.spolyf.SportStarMinRepository;
import com.core.spolyf.SportStarRepository;




@CrossOrigin
@RestController
@RequestMapping("/sportstars")
public class SpolyfController {

     
    @Autowired
    SportStarRepository starRepository;
    
    @Autowired
    SportStarMinRepository starMinRepository;
    
    @Autowired
	protected MongoTemplate mongoTemplate;
	
	@Autowired
	protected MongoOperations mongoOperation;
	
   
                                                    
    @RequestMapping(method = RequestMethod.POST)
    public SportStar create(@RequestBody SportStar star){
    	SportStar result = starRepository.save(star);
        return result;
    }
    
    
    
     
    @RequestMapping(method = RequestMethod.GET, value="/{spolyf_id}")
    public SportStar get(@PathVariable String spolyf_id){
    	SportStar sportstar = null;
		Query query = new Query();
		query.addCriteria(Criteria.where("spolyf_id").is(spolyf_id));
		sportstar = mongoOperation.findOne(query, SportStar.class);
		return sportstar;
        //return starRepository.findOne(spolyf_id);
    }
    
     
    @RequestMapping(method = RequestMethod.GET)
    public List<SportStar> getall(){
        return starRepository.findAll();
    }
    
    @RequestMapping(method = RequestMethod.GET,value="/listing")
    public List<SportStarMin> getallmin(){
        return starMinRepository.findAll();
    }
    	
    @RequestMapping(method = RequestMethod.POST,value="/addall")
    public List<SportStar> createMany(@RequestBody List<SportStar> entities){
         
        List<SportStar> result = starRepository.save(entities);
        return result;
    }
    
}