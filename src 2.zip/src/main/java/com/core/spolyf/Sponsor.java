package com.core.spolyf;

/**
 * @author AHS
 * At present, Sponsor will be an individual, not an entity/company
 *
 */
public class Sponsor {

	private String sponsor_id;
	
	private String spolyf_id;
	
	private SportStar sportstar;
	
	private boolean isActive;
	
	private Tournament tournament;

	public String getSponsor_id() {
		return sponsor_id;
	}

	public void setSponsor_id(String sponsor_id) {
		this.sponsor_id = sponsor_id;
	}

	public String getSpolyf_id() {
		return spolyf_id;
	}

	public void setSpolyf_id(String spolyf_id) {
		this.spolyf_id = spolyf_id;
	}

	public SportStar getSportstar() {
		return sportstar;
	}

	public void setSportstar(SportStar sportstar) {
		this.sportstar = sportstar;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Tournament getTournament() {
		return tournament;
	}

	public void setTournament(Tournament tournament) {
		this.tournament = tournament;
	}
	
	
	
	
}
