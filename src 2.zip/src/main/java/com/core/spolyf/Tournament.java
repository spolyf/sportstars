package com.core.spolyf;

import java.util.HashMap;

public class Tournament {
	
	private String tournament_id;
	
	private String tournamentName;
	
	private HashMap<String,String> tournamentVenue;

	public String getTournament_id() {
		return tournament_id;
	}

	public void setTournament_id(String tournament_id) {
		this.tournament_id = tournament_id;
	}

	public String getTournamentName() {
		return tournamentName;
	}

	public void setTournamentName(String tournamentName) {
		this.tournamentName = tournamentName;
	}

	public HashMap<String, String> getTournamentVenue() {
		return tournamentVenue;
	}

	public void setTournamentVenue(HashMap<String, String> tournamentVenue) {
		this.tournamentVenue = tournamentVenue;
	}
	
	

}
