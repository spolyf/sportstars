package com.core.spolyf;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface SportStarMinRepository extends
MongoRepository<SportStarMin, String> {
 
}