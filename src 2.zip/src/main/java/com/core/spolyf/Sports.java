package com.core.spolyf;

public class Sports {
	
	private String id;
	private int sports_id;
	private String sportsName;
	private String SportsType;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getSports_id() {
		return sports_id;
	}
	public void setSports_id(int sports_id) {
		this.sports_id = sports_id;
	}
	public String getSportsName() {
		return sportsName;
	}
	public void setSportsName(String sportsName) {
		this.sportsName = sportsName;
	}
	public String getSportsType() {
		return SportsType;
	}
	public void setSportsType(String sportsType) {
		SportsType = sportsType;
	}
	
	

}
