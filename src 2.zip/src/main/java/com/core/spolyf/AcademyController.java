package com.core.spolyf;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@CrossOrigin
@RestController
@RequestMapping("/academy")
public class AcademyController {

     
    @Autowired
    AcademyRepository academyRepository;
    
    @Autowired
	protected MongoTemplate mongoTemplate;
	
	@Autowired
	protected MongoOperations mongoOperation;
	
    

                                                    
    @RequestMapping(method = RequestMethod.POST)
    public Academy create(@RequestBody Academy academy){
    	Academy result = academyRepository.save(academy);
        return result;
    }
    
    
    
     
    @RequestMapping(method = RequestMethod.GET, value="/{academy_id}")
    public Academy get(@PathVariable String academy_id){
    	Academy academy = null;
    	Query query = new Query();
    	query.addCriteria(Criteria.where("academy_id").is(academy_id));
    	academy = mongoOperation.findOne(query, Academy.class);
        return academy;
    }
    
    @RequestMapping(method = RequestMethod.GET, value="/spolyf_id/{spolyf_id}")
    public List<Academy> getAcademyBySpolyf(@PathVariable String spolyf_id){
    	List<Academy> academy = null;
    	Query query = new Query();
    	query.addCriteria(Criteria.where("sportstars").all(spolyf_id));
    	academy = mongoOperation.find(query, Academy.class);
        return academy;
    }
    
     
    @RequestMapping(method = RequestMethod.GET)
    public List<Academy> getall(){
        return academyRepository.findAll();
    }
    
    
    	
    @RequestMapping(method = RequestMethod.POST,value="/addall")
    public List<Academy> createMany(@RequestBody List<Academy> entities){
         
        List<Academy> result = academyRepository.save(entities);
        return result;
    }
    
    
   
	public Academy getAcademyBySpolyfId(String spolyf_id) {
		Academy academy = null;
		Query query = new Query();
		query.addCriteria(Criteria.where("spolyf_id").is(spolyf_id));
		academy = mongoOperation.findOne(query, Academy.class);
		return academy;
	}

    
    
    
}